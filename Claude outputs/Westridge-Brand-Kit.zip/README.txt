WESTRIDGE PRIVATE AVIATION
Brand Kit, Direction A: Ridgeline at Dusk

LOGOS
  logos/svg   Vector, text converted to outlines. Use for print and web.
  logos/pdf   Vector, fonts embedded.
  logos/png   Transparent, 4x resolution.

  "ink" files are for light backgrounds. "fog" files are for dark backgrounds.
  lockup-stacked      Primary lockup: mark above wordmark.
  lockup-horizontal   Mark beside wordmark. Headers, signatures.
  wordmark            WESTRIDGE with the Private Aviation descriptor.
  wordmark-only       WESTRIDGE alone.
  mark                The ridgeline mark, with the brass dot.
  mark-small          Simplified mark for 32 px and below (favicons, app icons).

  Clear space: the height of the mark on every side.
  Minimum size: 16 px mark, 96 px wordmark.
  Never place the logo on an aircraft.

COLOR
  color/palette.css and color/palette.json
  Slate Ink #1F2A33, Fog #ECEAE5, Granite #8B8F8A, Brass #A9875A,
  Deep Ink #141C23, Granite Dark #565C58.
  Brass is for rules and marks only. It fails contrast as text on Fog.

TYPE
  Display and headings: Bodoni Moda, weights 400 and 500.
  Text, labels, buttons: Hanken Grotesk, weights 400, 500 and 600.
  Both are free under the SIL Open Font License:
  https://fonts.google.com/specimen/Bodoni+Moda
  https://fonts.google.com/specimen/Hanken+Grotesk

GUIDELINES
  guidelines/Westridge-Brand-Guidelines.pdf   Logo, color, type scale,
  photography direction, business card, email signature, itinerary cover,
  Instagram post.
  guidelines/pages   The same pages as PNG.

PHOTOGRAPHY
  Photos in the guidelines are Unsplash reference shots, graded to the palette.
  They are not included as separate files.
